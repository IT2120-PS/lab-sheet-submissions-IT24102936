setwd("C:\\Users\\BuyMore\\Desktop\\IT24102936")


#Question 1
#i
#Binomial Distribution


#ii


1-pbinom(46,50,0.85,lower.tail = TRUE)




#Question 2
#i
#number of customer calls in a certain hour


#ii
#Poisson distribution

  
  
#iii
dpois(15,12)
  