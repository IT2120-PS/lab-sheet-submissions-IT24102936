setwd("C:/Users/MY/Desktop/IT24102898")
getwd()
sum((1:15)%%3==0)


v <- c(4, 10, 7, 3)
max_index <- 1
for (i in 2:length(v)) {
  if (v[i] > v[max_index]) {
    max_index <- i
  }
}
max_index

which.max(v)



