setwd("C:/Users/samar/OneDrive - Sri Lanka Institute of Information Technology/Y2 S1/PS/LAB5")

Delivery_Times <- read.table("Exercise – Lab 05.txt", header = TRUE)
fix(Delivery_Times)


names(Delivery_Times) <- c("X1")

attach(Delivery_Times)

histogram <- hist(X1, 
                  breaks = seq(20, 70, length.out = 10), 
                  right = TRUE, 
                  main = "Delivery Times", 
                  xlab = "Delivery Time", 
                  ylab = "Frequency")

cum_freq <- cumsum(histogram$counts)

plot(histogram$mids, cum_freq, 
     type = "l", 
     main = "Ogive of Delivery Times", 
     xlab = "Delivery Time", 
     ylab = "Cumulative Frequency")

points(histogram$mids, cum_freq)

